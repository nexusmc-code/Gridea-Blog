# 介绍
一款基于 HTML5 UP 的 Multiverse 模板开发的， Gridea 主题。

# 参考
- [HTML5 UP / Multiverse](https://html5up.net/multiverse)
- [getgridea / gridea-theme-starter](https://github.com/getgridea/gridea-theme-starter)
- [wclk / time](https://github.com/wclk/time)
- [getgridea / gridea-theme-notes](https://github.com/getgridea/gridea-theme-notes)
- [hsxyhao / gridea-theme-next](https://github.com/hsxyhao/gridea-theme-next)
- [HTML5 UP / Lens](https://html5up.net/lens)

# 更新记录

## 正式版

# 1.0.3
- 修正 Lens 布局下，无法切换上下页的问题。顺便修改了一下 Multiverse 布局下，代码不自然的问题。

2020年04月16日14:14:45
修改 `footer.ejs` 文件。
```HTML
...
<% if (scheme === 'lens') {%>
<ul class="copyright">
    <li><%= themeConfig.siteName %></li><li> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</li>
</ul>
<% } else {%>
...
```
```HTML
...
<ul class="icons">
    <% if (pagination.prev) { %>
    <li><a href="<%= pagination.prev %>" class="icon solid fa-angle-left"></a></li>
    <% } %>
    <% if (pagination.next) { %>
    <li><a href="<%= pagination.next %>" class="icon solid fa-angle-right"></a></li>
    <% } %>
</ul>
<ul class="copyright">
    <li><%= themeConfig.siteName %></li><li> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</li>
</ul>
...
```
修改 `header.ejs` 文件。
```HTML
...
<% } else {%>
<h1><strong><%= themeConfig.siteName %></strong> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</h1>
<nav>
    <ul>
        <% if (pagination.prev) { %>
            <li><a href="<%= pagination.prev %>" class="icon solid fa-angle-left"></a></li>
        <% } %>
        <% if (pagination.next) { %>
            <li><a href="<%= pagination.next %>" class="icon solid fa-angle-right"></a></li>
        <% } %>
        <li><a href="#footer" class="icon solid fa-info-circle">关于</a></li>
    </ul>
</nav>
<% } %>
...
```
```HTML
...
<% } else {%>
<h1><strong><%= themeConfig.siteName %></strong> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</h1>
<nav>
    <ul>
        <% if (pagination.prev) { %>
        <li><a href="<%= pagination.prev %>" class="icon solid fa-angle-left"></a></li>
        <% } %>
        <% if (pagination.next) { %>
        <li><a href="<%= pagination.next %>" class="icon solid fa-angle-right"></a></li>
        <% } %>
        <li><a href="#footer" class="icon solid fa-info-circle">关于</a></li>
    </ul>
</nav>
<% } %>
...
```
2020年04月16日14:15:17

- 修改注释内容，不同布局显示不同注释。

2020年04月16日14:24:17
修改 `index.ejs` 文件。
```HTML
...
<!--
	Multiverse by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
...
```
```HTML
...
<!--
	<% if (scheme === 'lens') {%>Lens<% } else {%>Multiverse<% } %> by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
...
```
2020年04月16日14:24:56

# 1.0.2
- 新增 html5up-Lens 模板，只需一键，即可无缝切换。

2020年04月15日13:42:03
前期准备。
调整静态资源目录内容。
2020年04月15日13:51:34
2020年04月15日14:22:57
修改 `config.json` 文件。
```JSON
    ...
    {
      "name": "scheme",
      "label": "外观",
      "group": "布局",
      "value": "multiverse",
      "type": "radio",
      "options": [
        {
          "label": "multiverse 多次元",
          "value": "multiverse"
        },
        {
          "label": "lens 棱镜",
          "value": "lens"
        }
      ]
    },
    ...
```
2020年04月15日14:24:50
2020年04月15日21:26:51
修改 `index.ejs` 文件。
```HTML
...
<!-- 脚本 -->
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/jquery.poptrox.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/util.js"></script>
<script src="media/scripts/main.js"></script>
...
```
```HTML
<!-- 脚本 -->
<% if (site.customConfig.scheme === 'lens') {%>
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/main-lens.js"></script>
<% } else {%>
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/jquery.poptrox.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/util-multiverse.js"></script>
<script src="media/scripts/main-multiverse.js"></script>
<% } %>
```
修改 `head.ejs` 文件。
```HTML
...
<link rel="stylesheet" href="media/css/main.css" />
<link rel="stylesheet" href="media/css/style.css" />
<noscript><link rel="stylesheet" href="media/css/noscript.css" /></noscript>
...
```
```HTML
<% let scheme = site.customConfig.scheme; %><% if (scheme === 'lens') {%>
<link rel="stylesheet" href="media/css/main-lens.css" />
<noscript><link rel="stylesheet" href="media/css/noscript-lens.css" /></noscript>
<% } else {%>
<link rel="stylesheet" href="media/css/main-multiverse.css" />
<link rel="stylesheet" href="media/css/modify-multiverse.css" />
<noscript><link rel="stylesheet" href="media/css/noscript-multiverse.css" /></noscript>
<% } %>
```
修改 `header.ejs` 文件。
```HTML
<header id="header">
    <h1><strong><%= themeConfig.siteName %></strong> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</h1>
    <nav>
        <ul>
            <% if (pagination.prev) { %>
                <li><a href="<%= pagination.prev %>" class="icon solid fa-angle-left"></a></li>
            <% } %>
            <% if (pagination.next) { %>
                <li><a href="<%= pagination.next %>" class="icon solid fa-angle-right"></a></li>
            <% } %>
            <li><a href="#footer" class="icon solid fa-info-circle">关于</a></li>
        </ul>
    </nav>
</header>
```
```HTML
<header id="header">
    <% let scheme = site.customConfig.scheme; %><% if (scheme === 'lens') {%>
    <h1><%= themeConfig.siteName %></h1>
    <p><%- themeConfig.siteDescription %></p>
    <ul class="icons">
        <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
            <% if (site.customConfig[item]) { %>
            <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"><span class="label"><%= item %></span></a></li>
            <% } %>
        <% }) %>
    </ul>
    <% } else {%>
    <h1><strong><%= themeConfig.siteName %></strong> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</h1>
    <nav>
        <ul>
            <% if (pagination.prev) { %>
                <li><a href="<%= pagination.prev %>" class="icon solid fa-angle-left"></a></li>
            <% } %>
            <% if (pagination.next) { %>
                <li><a href="<%= pagination.next %>" class="icon solid fa-angle-right"></a></li>
            <% } %>
            <li><a href="#footer" class="icon solid fa-info-circle">关于</a></li>
        </ul>
    </nav>
    <% } %>
</header>
```
2020年04月15日21:35:11
2020年04月15日21:44:55
修改 `footer.ejs` 文件。
```HTML
<footer id="footer" class="panel">
    <div class="inner split">
        <div>
            <section>
                <h2>关于</h2>
                <p><%- themeConfig.siteDescription %></p>
            </section>
            <section>
                <h2>求订阅我的...</h2>
                <ul class="icons">
                    <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
                        <% if (site.customConfig[item]) { %>
                            <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"><span class="label">Twitter</span></a></li>
                        <% } %>
                    <% }) %>
                </ul>
            </section>
            <p class="copyright"><%- themeConfig.footerInfo %></p>
        </div>
    </div>
</footer>
```
```HTML
<% let scheme = site.customConfig.scheme; %>
<footer id="footer" <% if (scheme !== 'lens') {%>class="panel"<% } %>>
    <% if (scheme === 'lens') {%>
    <ul class="copyright">
        <li><%= themeConfig.siteName %></li><li> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</li>
    </ul>
    <% } else {%>
    <div class="inner split">
        <div>
            <section>
                <h2>关于</h2>
                <p><%- themeConfig.siteDescription %></p>
            </section>
            <section>
                <h2>求订阅我的...</h2>
                <ul class="icons">
                    <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
                        <% if (site.customConfig[item]) { %>
                            <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"><span class="label"><%= item %></span></a></li>
                        <% } %>
                    <% }) %>
                </ul>
            </section>
            <p class="copyright"><%- themeConfig.footerInfo %></p>
        </div>
    </div>
    <% } %>
</footer>
```
修改 `post-list.ejs` 文件。
```HTML
<main id="main">
    <% posts.forEach(function(post) { %>
        <article class="thumb">
            <% if (post.feature) { %>
                <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
            <% } %>
            <h2><%= post.title %></h2>
            <%- post.content %>
        </article>
    <% }); %>
</main>
```
```HTML
<% if (site.customConfig.scheme === 'lens') {%>
    <% posts.forEach(function(post) { %>
        <article>
        <% if (post.feature) { %>
        <a class="thumbnail" href="<%= post.feature %>"><img src="<%= post.feature %>" alt="" /></a>
        <% } %>
        <h2><%= post.title %></h2>
        <%- post.content %>
    </article>
    <% }); %>
<% } else {%><main id="main">
    <% posts.forEach(function(post) { %>
    <article class="thumb">
        <% if (post.feature) { %>
            <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
        <% } %>
        <h2><%= post.title %></h2>
        <%- post.content %>
    </article>
    <% }); %>
</main>
<% } %>
```
2020年04月15日21:51:11
2020年04月15日21:57:11
修改 `index.ejs` 文件。
```HTML
...
<body class="is-preload">
...
<div id="wrapper">
...
```
```HTML
...
<body <% if (scheme === 'lens') {%>class="is-preload-0 is-preload-1 is-preload-2"<% } else {%>class="is-preload"<% } %>>
...
<div <% if (scheme === 'lens') {%>id="main"<% } else {%>id="wrapper"<% } %>>
...
```
修改 `post-list.ejs` 文件。
```HTML
<% if (site.customConfig.scheme === 'lens') {%>
    <% posts.forEach(function(post) { %>
        <article>
        <% if (post.feature) { %>
        <a class="thumbnail" href="<%= post.feature %>"><img src="<%= post.feature %>" alt="" /></a>
        <% } %>
        <h2><%= post.title %></h2>
        <%- post.content %>
    </article>
    <% }); %>
<% } else {%>
<main id="main">
    <% posts.forEach(function(post) { %>
    <article class="thumb">
        <% if (post.feature) { %>
            <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
        <% } %>
        <h2><%= post.title %></h2>
        <%- post.content %>
    </article>
    <% }); %>
</main>
<% } %>
```
```HTML
<% if (site.customConfig.scheme === 'lens') {%>
<section id="thumbnails">
    <% posts.forEach(function(post) { %>
        <article>
        <% if (post.feature) { %>
        <a class="thumbnail" href="<%= post.feature %>"><img src="<%= post.feature %>" alt="" /></a>
        <% } %>
        <h2><%= post.title %></h2>
        <%- post.content %>
    </article>
    <% }); %>
</section>
<% } else {%>
<main id="main">
    <% posts.forEach(function(post) { %>
    <article class="thumb">
        <% if (post.feature) { %>
            <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
        <% } %>
        <h2><%= post.title %></h2>
        <%- post.content %>
    </article>
    <% }); %>
</main>
<% } %>
```
2020年04月15日22:00:13
参考 https://github.com/hsxyhao/gridea-theme-next
```
<% let scheme = site.customConfig.scheme; %><% if (scheme === 'lens') {%>
[新样式]
<% } else {%>
[旧样式]
<% } %>
```
- 去除其他页面的冗余代码。
2020年04月15日22:12:35
新增 `to-home.ejs` 文件。
```HTML
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>页面跳转 Page forwarding</title>
    <meta http-equiv="Cache-Control: no-cache, no-store, must-revalidate">
    <meta http-equiv="refresh" content="0;url=<%= themeConfig.domain %>" />
    <style>body, html{background:#303030;color:#fff;}a{text-decoration: none;color:#2196f3;transition: all .25s;}</style>
</head>
<body>

<p>你不该来到这，现在 <a href="<%= themeConfig.domain %>">请点此处</a> 回到正轨。<br>This is weird, <a href="<%= themeConfig.domain %>">click here</a> Back to home-page.</p>

</body>
</html>
```
修改 `tag.ejs`、`tags.ejs`、`post.ejs`和`archives.ejs` 文件。
```HTML

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>页面跳转 Page forwarding</title>
    <meta http-equiv="Cache-Control: no-cache, no-store, must-revalidate">
    <meta http-equiv="refresh" content="0;url=<%= themeConfig.domain %>" />
    <style>body, html{background:#303030;color:#fff;}a{text-decoration: none;color:#2196f3;transition: all .25s;}</style>
</head>
<body>

<p>你不该来到这，现在 <a href="<%= themeConfig.domain %>">请点此处</a> 回到正轨。<br>This is weird, <a href="<%= themeConfig.domain %>">click here</a> Back to home-page.</p>

</body>
</html>
```
```HTML
<%- include('includes/to-home') %>
```
2020年04月15日22:12:46

# 1.0.2-废弃
- 新增 html5up-Lens 模板，只需一键，即可无缝切换。

2020年04月15日13:42:03
前期准备。
调整静态资源目录内容。
2020年04月15日13:51:34
2020年04月15日14:22:57
修改 `config.json` 文件。
```JSON
    ...
    {
      "name": "scheme",
      "label": "外观",
      "group": "布局",
      "value": "multiverse",
      "type": "radio",
      "options": [
        {
          "label": "multiverse 多次元",
          "value": "multiverse"
        },
        {
          "label": "lens 棱镜",
          "value": "lens"
        }
      ]
    },
    ...
```
2020年04月15日14:24:50
2020年04月15日14:34:44
```HTML
<header id="header">
    <h1><strong><%= themeConfig.siteName %></strong> 由 <a href="https://html5up.net">HTML5 UP</a> 设计样式。</h1>
    <nav>
        <ul>
            <% if (pagination.prev) { %>
                <li><a href="<%= pagination.prev %>" class="icon solid fa-angle-left"></a></li>
            <% } %>
            <% if (pagination.next) { %>
                <li><a href="<%= pagination.next %>" class="icon solid fa-angle-right"></a></li>
            <% } %>
            <li><a href="#footer" class="icon solid fa-info-circle">关于</a></li>
        </ul>
    </nav>
</header>
```
```HTML
<% if (themeConfig.scheme == 'multiverse') { %>
...
<% } else {%>
<header id="header">
    <h1><%= themeConfig.siteName %></h1>
    <p><%- themeConfig.siteDescription %></p>
    <ul class="icons">
        <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
            <% if (site.customConfig[item]) { %>
                <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"><span class="label"><%= item %></span></a></li>
            <% } %>
        <% }) %>
    </ul>
</header>
<% } %>
```
2020年04月15日14:40:38
2020年04月15日14:45:57
修改 `footer.ejs` 文件。
```HTML
<footer id="footer" class="panel">
    <div class="inner split">
        <div>
            <section>
                <h2>关于</h2>
                <p><%- themeConfig.siteDescription %></p>
            </section>
            <section>
                <h2>求订阅我的...</h2>
                <ul class="icons">
                    <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
                        <% if (site.customConfig[item]) { %>
                            <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"></a></li>
                        <% } %>
                    <% }) %>
                </ul>
            </section>
            <p class="copyright"><%- themeConfig.footerInfo %></p>
        </div>
    </div>
</footer>
```
```HTML
<% if (themeConfig.scheme == 'multiverse') { %>
...
<% } else {%>
<footer id="footer">
    <ul class="copyright">
        <li>&copy; <%= themeConfig.siteName %></li><li>由 <a href="http://html5up.net">HTML5 UP</a> 设计样式。</li>
    </ul>
</footer>
<% } %>
```
修改 `post-list.ejs` 文件。
```HTML
<main id="main">
    <% posts.forEach(function(post) { %>
        <article class="thumb">
            <% if (post.feature) { %>
                <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
            <% } %>
            <h2><%= post.title %></h2>
            <%- post.content %>
        </article>
    <% }); %>
</main>
```
```HTML
<% if (themeConfig.scheme == 'multiverse') { %>
<main id="main">
    <% posts.forEach(function(post) { %>
        <article class="thumb">
            <% if (post.feature) { %>
            <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
            <% } %>
            <h2><%= post.title %></h2>
            <%- post.content %>
        </article>
    <% }); %>
</main>
<% } else {%>
    <section id="thumbnails">
        <% posts.forEach(function(post) { %>
        <article>
            <% if (post.feature) { %>
            <a class="thumbnail" href="<%= post.feature %>" data-position="left center"><img src="<%= post.feature %>" alt="" /></a>
            <% } %>
            <h2><%= post.title %></h2>
            <%- post.content %>
        </article>
        <% }); %>
    </section>
<% } %>
```
2020年04月15日14:48:34
2020年04月15日14:53:12
修改 `head.ejs` 文件。
```HTML
...
<link rel="stylesheet" href="media/css/main.css" />
<link rel="stylesheet" href="media/css/style.css" />
<noscript><link rel="stylesheet" href="media/css/noscript.css" /></noscript>
...
```
```HTML
...
<% if (themeConfig.scheme == 'multiverse') { %>
<link rel="stylesheet" href="media/css/main-multiverse.css" />
<link rel="stylesheet" href="media/css/modify-multiverse.css" />
<noscript><link rel="stylesheet" href="media/css/noscript-multiverse.css" /></noscript>
<% } else {%>
<link rel="stylesheet" href="media/css/main-lens.css" />
<noscript><link rel="stylesheet" href="media/css/noscript-lens.css" /></noscript>
<% } %>
...
```
2020年04月15日14:54:54
2020年04月15日14:59:42
修改 `index.ejs` 文件。
```HTML
...
<!-- 脚本 -->
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/jquery.poptrox.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/util.js"></script>
<script src="media/scripts/main.js"></script>
...
```
```HTML
...
<!-- 脚本 -->
<% if (themeConfig.scheme == 'multiverse') { %>
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/jquery.poptrox.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/util.js"></script>
<script src="media/scripts/main.js"></script>
<% } else {%>
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/main-lens.js"></script>
<% } %>
...
```
2020年04月15日15:00:20


- 参考 https://github.com/hsxyhao/gridea-theme-next

- 去除其他页面的重复代码。

# 1.0.1
- 修正页眉中图标与文字不对其的问题。
- 修正页眉中按下“关于”内容背景颜色不变的问题。

2020年04月05日12:59:16
修改 `style.css` 文件。
```CSS
.icon {
    line-height: initial;
}
#header nav > ul > li a.active {
    background-color: unset;
}
```
```CSS
.icon {
    vertical-align: middle;
    transform: translateY(-.1em);
}
```
2020年04月05日13:00:05
- 参考自 http://f2ex.cn/material-icons-align

# 1.0.0
- 首个正式版版本发布。

## 内部调试版

### 0.0.2
- 修正无法正常导出的问题。

2020年03月20日10:47:29
修改 `tag.ejs`、`tags.ejs`、`post.ejs`和`archives.ejs` 文件。
```HTML
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>页面跳转 Page forwarding</title>
    <meta http-equiv="Cache-Control: no-cache, no-store, must-revalidate">
    <meta http-equiv="refresh" content="0;url=<%= themeConfig.domain %>" />
    <style>body, html{background:#303030;color:#fff;}a{text-decoration: none;color:#2196f3;transition: all .25s;}</style>
</head>
<body>

<p>你不该来到这，现在 <a href="<%= themeConfig.domain %>">请点此处</a> 回到正轨。<br>This is weird, <a href="<%= themeConfig.domain %>">click here</a> Back to home-page.</p>

</body>
</html>
```
2020年03月20日10:56:49
2020年03月20日11:00:41
修改 `index.ejs`。
```HTML
    <%- include('includes/head' %>
```
```HTML
    <%- include('includes/head') %>
```
2020年03月20日11:00:50
2020年03月20日11:09:17
修改 `post-list.ejs`。
```HTML
<article class="thumb">
    <% if (post.feature) { %>
        <a href="<%= post.feature %>'" class="image"><img src="<%= post.feature %>" /></a>
    <% } %>
    <h2><%= post.title %></h2>
    <%- post.content %>
</article>
```
```HTML
<main id="main">
    <% posts.forEach(function(post) { %>
        <article class="thumb">
            <% if (post.feature) { %>
                <a href="<%= post.feature %>" class="image"><img src="<%= post.feature %>" /></a>
            <% } %>
            <h2><%= post.title %></h2>
            <%- post.content %>
        </article>
    <% }); %>
</main>
```
修改 `index.ejs`。
```HTML
    <!-- 主要内容 -->
    <div id="main">
        <%- include('includes/post-list') %>
    </div>
```
```HTML
    <!-- 主要内容 -->
    <%- include('includes/post-list') %>
```
2020年03月20日11:11:10

- 修正脚本加载异常的问题。

2020年03月20日11:16:05
修改 `index.ejs`。
```HTML
<!-- 脚本 -->
<script src="media/script/jquery.min.js"></script>
<script src="media/script/jquery.poptrox.min.js"></script>
<script src="media/script/browser.min.js"></script>
<script src="media/script/breakpoints.min.js"></script>
<script src="media/script/util.js"></script>
<script src="media/script/main.js"></script>
```
```HTML
<!-- 脚本 -->
<script src="media/scripts/jquery.min.js"></script>
<script src="media/scripts/jquery.poptrox.min.js"></script>
<script src="media/scripts/browser.min.js"></script>
<script src="media/scripts/breakpoints.min.js"></script>
<script src="media/scripts/util.js"></script>
<script src="media/scripts/main.js"></script>
```
2020年03月20日11:16:36

- 修正页脚的问题。

2020年03月20日11:23:16
修改 `index.ejs`。
```HTML
<footer id="footer" class="panel">
    <div class="inner split">
        <div>
            <section>
                <h2>关于</h2>
                <p>Nulla consequat, ex ut suscipit rutrum, mi dolor tincidunt erat, et scelerisque turpis ipsum eget quis orci mattis aliquet. Maecenas fringilla et ante at lorem et ipsum. Dolor nulla eu bibendum sapien. Donec non pharetra dui. Nulla consequat, ex ut suscipit rutrum, mi dolor tincidunt erat, et scelerisque turpis ipsum.</p>
            </section>
            <section>
                <h2>求订阅我...</h2>
                <ul class="icons">
                    <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
                        <% if (site.customConfig[item]) { %>
                            <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"><span class="label">Twitter</span></a></li>
                        <% } %>
                    <% }) %>
                </ul>
            </section>
            <p class="copyright"><%- themeConfig.footerInfo %></p>
        </div>
    </div>
</footer>


```
```HTML
<footer id="footer" class="panel">
    <div class="inner split">
        <div>
            <section>
                <h2>关于</h2>
                <p><%- themeConfig.siteDescription %></p>
            </section>
            <section>
                <h2>求订阅我...</h2>
                <ul class="icons">
                    <% ['github', 'twitter', 'weibo', 'zhihu', 'facebook'].forEach((item) => { %>
                        <% if (site.customConfig[item]) { %>
                            <li><a href="<%= site.customConfig[item] %>" class="icon brands fa-<%= item %>"><span class="label">Twitter</span></a></li>
                        <% } %>
                    <% }) %>
                </ul>
            </section>
            <p class="copyright"><%- themeConfig.footerInfo %></p>
        </div>
    </div>
</footer>
```
2020年03月20日11:26:32

- 修正搜索引擎优化错误。

2020年03月20日11:30:25
修改 `config.json` 文件。
```JSON
    {
      "name": "metaKeyword",
      "label": "Meta Keyword",
      "group": "SEO",
      "value": "相册, Gallery",
      "type": "input"
    },
```
```JSON
    {
      "name": "metaKeywords",
      "label": "Meta Keywords",
      "group": "SEO",
      "value": "相册, Gallery",
      "type": "input"
    },
```
2020年03月20日11:31:42


### 0.0.1
- 首个版本发布。
2020年03月20日09:27:01
2020年03月20日10:27:09